@echo off
title Servidor - Dias de um Apocalipse
cd /d "%~dp0"
rem Nome que aparece para os amigos (pode mudar entre as aspas):
set NOME=Servidor do PC
DiasDeUmApocalipse_Servidor.console.exe --headless -- --servidor --nome="%NOME%"
echo.
echo O servidor parou. Feche esta janela.
pause
