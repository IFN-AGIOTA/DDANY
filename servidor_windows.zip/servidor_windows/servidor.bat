@echo off
title Servidor - Dias de um Apocalipse
cd /d "%~dp0"
rem Nome que aparece para os amigos (pode mudar entre as aspas):
set NOME=Servidor do PC
rem Mundo salvo (como no Minecraft). Vazio = um mundo com o nome do servidor. Nome novo = mundo novo:
set MUNDO=
rem Endereco do tunel do playit.gg (ex.: xxx-yyy.gl.at.ply.gg:12345). Deixe vazio se nao usar:
set ENDERECO=
DiasDeUmApocalipse_Servidor.console.exe --headless -- --servidor --nome="%NOME%" --mundo="%MUNDO%" --endereco="%ENDERECO%"
echo.
echo O servidor parou. Feche esta janela.
pause
