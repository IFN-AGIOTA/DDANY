@echo off
rem Abre a porta do servidor no firewall do Windows e no roteador (UPnP). "abrir_portas.bat fechar" desfaz.
cd /d "%~dp0"
set ACAO=%1
if "%ACAO%"=="" set ACAO=abrir
net session >nul 2>&1
if errorlevel 1 (
  echo Pedindo permissao de administrador...
  powershell -NoProfile -Command "Start-Process -FilePath \"%~f0\" -ArgumentList \"%ACAO%\" -Verb RunAs"
  exit /b
)
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0abrir_portas.ps1" %ACAO%
pause
