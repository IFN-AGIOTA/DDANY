﻿﻿# ABRIR PORTAS do servidor (Dias de um Apocalipse). Chamado pelo abrir_portas.bat (que já pede administrador).
#   1) libera a porta UDP 24560 no FIREWALL do Windows (todas as redes: Wi-Fi, cabo, Tailscale)
#   2) liga a DESCOBERTA DE REDE do Windows (rede de casa como "Particular", regras e serviços SSDP/UPnP)
#   3) pede ao ROTEADOR para abrir a porta 24560 (UPnP): primeiro pelo Windows; se não der, fala direto com o
#      roteador (procura na rede com SSDP e manda o pedido AddPortMapping)
#   4) confere se a sua internet tem CGNAT (aí porta nenhuma funciona de fora: use o Tailscale)
#   5) se o roteador não aceitar: abre a página do roteador no navegador e mostra o que preencher
# "abrir_portas.bat fechar" desfaz (firewall e porta no roteador).
param([string]$acao = "abrir")

$PORTA = 24560
$NOME = "Dias de um Apocalipse - Servidor"
$ErrorActionPreference = "SilentlyContinue"

function Linha([string]$t, [string]$cor = "Gray") { Write-Host $t -ForegroundColor $cor }

function Config {
    return Get-NetIPConfiguration | Where-Object { $_.IPv4DefaultGateway -ne $null -and $_.NetAdapter.Status -eq "Up" } | Select-Object -First 1
}

function IpPrivado([string]$ip) {
    if (-not $ip) { return $true }
    $p = $ip.Split(".") | ForEach-Object { [int]$_ }
    if ($p[0] -eq 10) { return $true }
    if ($p[0] -eq 192 -and $p[1] -eq 168) { return $true }
    if ($p[0] -eq 172 -and $p[1] -ge 16 -and $p[1] -le 31) { return $true }
    if ($p[0] -eq 100 -and $p[1] -ge 64 -and $p[1] -le 127) { return $true }   # faixa do CGNAT
    return $false
}

# ---------- UPnP pelo Windows (serviço do Windows) ----------
function MapeamentosWindows {
    $nat = New-Object -ComObject HNetCfg.NATUPnP
    if (-not $nat) { return $null }
    return $nat.StaticPortMappingCollection
}

# ---------- UPnP direto com o roteador (não depende do serviço do Windows) ----------
# acha o roteador (SSDP) e devolve @{url = endereço de controle; tipo = serviço WANIPConnection/WANPPPConnection}
function AcharRoteador([string]$ipLocal) {
    $locais = @()
    if ($env:DDA_UPNP_LOCATION) { $locais += $env:DDA_UPNP_LOCATION }     # testes
    else {
        $udp = New-Object System.Net.Sockets.UdpClient (New-Object System.Net.IPEndPoint ([System.Net.IPAddress]::Parse($ipLocal)), 0)
        $udp.Client.ReceiveTimeout = 1500
        $grupo = New-Object System.Net.IPEndPoint ([System.Net.IPAddress]::Parse("239.255.255.250")), 1900
        foreach ($st in @("urn:schemas-upnp-org:device:InternetGatewayDevice:1", "urn:schemas-upnp-org:service:WANIPConnection:1",
                          "urn:schemas-upnp-org:service:WANPPPConnection:1", "urn:schemas-upnp-org:device:InternetGatewayDevice:2")) {
            $msg = "M-SEARCH * HTTP/1.1`r`nHOST: 239.255.255.250:1900`r`nMAN: `"ssdp:discover`"`r`nMX: 2`r`nST: $st`r`n`r`n"
            $b = [System.Text.Encoding]::ASCII.GetBytes($msg)
            [void]$udp.Send($b, $b.Length, $grupo)
        }
        $fim = (Get-Date).AddSeconds(4)
        while ((Get-Date) -lt $fim) {
            try {
                $de = New-Object System.Net.IPEndPoint ([System.Net.IPAddress]::Any), 0
                $r = [System.Text.Encoding]::ASCII.GetString($udp.Receive([ref]$de))
                foreach ($l in $r -split "`r`n") {
                    if ($l -match "^LOCATION:\s*(.+)$") { $u = $Matches[1].Trim(); if ($locais -notcontains $u) { $locais += $u } }
                }
            } catch { }
        }
        $udp.Close()
    }
    foreach ($loc in $locais) {
        try {
            $xml = [xml](Invoke-WebRequest -Uri $loc -UseBasicParsing -TimeoutSec 5).Content
            $base = if ($xml.root.URLBase) { $xml.root.URLBase.TrimEnd("/") } else { ([System.Uri]$loc).GetLeftPart([System.UriPartial]::Authority) }
            foreach ($s in $xml.GetElementsByTagName("service")) {
                $t = $s.serviceType
                if ($t -match "WANIPConnection|WANPPPConnection") {
                    $c = $s.controlURL
                    if ($c -notmatch "^http") { $c = $base + "/" + $c.TrimStart("/") }
                    return @{ url = $c; tipo = $t }
                }
            }
        } catch { }
    }
    return $null
}

function Soap($rot, [string]$metodo, [string]$params) {
    $corpo = "<?xml version=`"1.0`"?><s:Envelope xmlns:s=`"http://schemas.xmlsoap.org/soap/envelope/`" " +
             "s:encodingStyle=`"http://schemas.xmlsoap.org/soap/encoding/`"><s:Body><u:$metodo xmlns:u=`"$($rot.tipo)`">" +
             $params + "</u:$metodo></s:Body></s:Envelope>"
    $cab = @{ SOAPAction = "`"$($rot.tipo)#$metodo`"" }
    try {
        $r = Invoke-WebRequest -Uri $rot.url -Method Post -Body $corpo -ContentType "text/xml; charset=utf-8" -Headers $cab -UseBasicParsing -TimeoutSec 6
        return @{ ok = $true; texto = $r.Content }
    } catch {
        return @{ ok = $false; texto = "$($_.Exception.Message)" }
    }
}

function AbrirDireto($rot, [string]$ip) {
    foreach ($prazo in @(0, 604800)) {           # alguns roteadores não aceitam "para sempre" (0): tenta 7 dias
        $a = "<NewRemoteHost></NewRemoteHost><NewExternalPort>$PORTA</NewExternalPort><NewProtocol>UDP</NewProtocol>" +
             "<NewInternalPort>$PORTA</NewInternalPort><NewInternalClient>$ip</NewInternalClient><NewEnabled>1</NewEnabled>" +
             "<NewPortMappingDescription>$NOME</NewPortMappingDescription><NewLeaseDuration>$prazo</NewLeaseDuration>"
        $r = Soap $rot "AddPortMapping" $a
        if ($r.ok) { return $prazo }
    }
    return -1
}

function IpExternoDireto($rot) {
    $r = Soap $rot "GetExternalIPAddress" ""
    if ($r.ok -and $r.texto -match "<NewExternalIPAddress>([^<]*)</NewExternalIPAddress>") { return $Matches[1].Trim() }
    return $null
}

function FecharDireto($rot) {
    $a = "<NewRemoteHost></NewRemoteHost><NewExternalPort>$PORTA</NewExternalPort><NewProtocol>UDP</NewProtocol>"
    return (Soap $rot "DeletePortMapping" $a).ok
}

# ---------- Descoberta de rede do Windows ----------
function LigarDescoberta($cfg) {
    $perfil = Get-NetConnectionProfile -InterfaceIndex $cfg.InterfaceIndex
    if ($perfil -and $perfil.NetworkCategory -eq "Public") {
        Set-NetConnectionProfile -InterfaceIndex $cfg.InterfaceIndex -NetworkCategory Private
        Linha "[windows] a rede '$($perfil.Name)' estava como PUBLICA: mudei para PARTICULAR (rede de casa)." "Green"
    }
    # regras "Descoberta de Rede" (nome que vale em qualquer idioma do Windows)
    Set-NetFirewallRule -Group "@FirewallAPI.dll,-32752" -Profile Private -Enabled True
    Enable-NetFirewallRule -Group "@FirewallAPI.dll,-32752"
    foreach ($svc in @("SSDPSRV", "upnphost", "fdPHost", "FDResPub")) {
        Set-Service -Name $svc -StartupType Manual
        Start-Service -Name $svc
    }
    Linha "[windows] Descoberta de rede LIGADA (serviços SSDP e UPnP iniciados)." "Green"
}

Linha ""
Linha "=== Dias de um Apocalipse - portas do servidor (UDP $PORTA) ===" "Cyan"
Linha ""

$cfg = Config
$ip = if ($cfg) { $cfg.IPv4Address.IPAddress } else { $null }
$gateway = if ($cfg) { $cfg.IPv4DefaultGateway.NextHop } else { $null }

if ($acao -eq "fechar") {
    Remove-NetFirewallRule -DisplayName $NOME
    Linha "[firewall] regra removida." "Yellow"
    $m = MapeamentosWindows
    if ($m) { $m.Remove($PORTA, "UDP") }
    if ($ip) { $rot = AcharRoteador $ip; if ($rot -and (FecharDireto $rot)) { Linha "[roteador] porta $PORTA fechada." "Yellow" } }
    Linha ""
    Linha "Pronto: portas fechadas."
    exit
}

# ---- 1) firewall do Windows
Remove-NetFirewallRule -DisplayName $NOME
$r = New-NetFirewallRule -DisplayName $NOME -Direction Inbound -Protocol UDP -LocalPort $PORTA -Action Allow -Profile Any
if ($r) { Linha "[firewall] OK: porta UDP $PORTA liberada no Windows (todas as redes)." "Green" }
else { Linha "[firewall] NAO deu (rode o abrir_portas.bat de novo e aceite o pedido de administrador)." "Red" }

if (-not $ip) {
    Linha "[rede] NAO achei a rede deste PC (o PC esta conectado no Wi-Fi/cabo?)." "Red"
    exit
}
Linha "[rede] IP deste PC na sua casa: $ip  ·  roteador: $gateway"

# ---- 2) Descoberta de rede
LigarDescoberta $cfg

# ---- 3) roteador (UPnP): pelo Windows e, se não der, direto
$externo = $null
$aberta = $false
Start-Sleep -Seconds 2
$m = MapeamentosWindows
if ($m) {
    $m.Remove($PORTA, "UDP")
    [void]$m.Add($PORTA, "UDP", $PORTA, $ip, $true, $NOME)
    $item = $m.Item($PORTA, "UDP")
    if ($item) { $aberta = $true; $externo = $item.ExternalIPAddress }
}
if (-not $aberta) {
    Linha "[roteador] procurando o roteador na rede (UPnP direto)..."
    $rot = AcharRoteador $ip
    if ($rot) {
        $prazo = AbrirDireto $rot $ip
        if ($prazo -ge 0) {
            $aberta = $true
            $externo = IpExternoDireto $rot
            if ($prazo -gt 0) { Linha "[roteador] (o roteador só aceitou por 7 dias: depois disso rode este arquivo de novo)" }
        } else {
            Linha "[roteador] o roteador RESPONDEU, mas RECUSOU abrir a porta." "Red"
        }
    } else {
        Linha "[roteador] o roteador NAO respondeu: o UPnP esta DESLIGADO dentro dele." "Red"
    }
}
if ($aberta) { Linha "[roteador] OK: porta $PORTA aberta para este PC ($ip)." "Green" }

# ---- 4) IP da internet e CGNAT
$publico = $null
try { $publico = (Invoke-RestMethod -Uri "https://api.ipify.org" -TimeoutSec 8).ToString().Trim() } catch {}
Linha ""
if ($publico) { Linha "[internet] seu IP na internet: $publico" }
if ($externo) { Linha "[internet] IP que o roteador recebe da operadora: $externo" }
Linha ""
if ($aberta -and $externo -and $publico -and ($externo -ne $publico -or (IpPrivado $externo))) {
    Linha "ATENCAO: sua operadora usa CGNAT (o roteador nao tem IP proprio na internet)." "Yellow"
    Linha "Abrir porta NAO adianta para quem esta fora de casa. Use o TAILSCALE (LEIA-ME_SERVIDOR.txt)." "Yellow"
    Linha "No mesmo Wi-Fi da sua casa continua funcionando normal ($ip)." "Yellow"
} elseif ($aberta) {
    Linha "TUDO CERTO! Amigos de fora entram no jogo com:   $publico" "Green"
    Linha "(no mesmo Wi-Fi da sua casa:   $ip)" "Green"
    Linha "Obs.: o IP da internet pode mudar quando o roteador reinicia: rode este arquivo de novo."
} else {
    # ---- 5) sem UPnP no roteador: abre a página dele e diz o que fazer
    Linha "FALTA SO UMA COISA, NA PAGINA DO ROTEADOR (o Windows ja esta pronto)." "Yellow"
    Linha "Vou abrir a pagina do roteador no navegador: http://$gateway" "Yellow"
    Linha ""
    Linha " 1. Usuario e senha do roteador: geralmente estao na ETIQUETA embaixo/atras do roteador"
    Linha "    (ex.: admin / admin, ou 'Senha de acesso'). Nao e a senha do Wi-Fi."
    Linha " 2. JEITO A (mais facil): procure 'UPnP' (em Avancado / Rede / NAT / Ferramentas) e LIGUE."
    Linha "    Salve e rode este abrir_portas.bat de novo: ele abre a porta sozinho."
    Linha " 3. JEITO B: procure 'Redirecionamento de portas' / 'Port Forwarding' / 'Servidor virtual' / 'NAT'"
    Linha "    e crie uma regra com:"
    Linha "        Nome ............... DDA" "White"
    Linha "        Porta externa ...... $PORTA" "White"
    Linha "        Porta interna ...... $PORTA" "White"
    Linha "        Protocolo .......... UDP" "White"
    Linha "        IP do computador ... $ip" "White"
    Linha "    Salve. Os amigos de fora entram com:  $publico"
    Linha ""
    Linha "Dica: o IP do PC ($ip) pode mudar quando o PC reinicia. No roteador, procure 'DHCP' >"
    Linha "'Reserva de IP' / 'IP fixo' e reserve $ip para este PC (assim a regra nao quebra)."
    Linha "Se o roteador for da operadora e nao tiver essas opcoes, ou se mesmo assim nao funcionar: TAILSCALE."
    if (-not $env:DDA_UPNP_LOCATION) { Start-Process "http://$gateway" }
}
Linha ""
