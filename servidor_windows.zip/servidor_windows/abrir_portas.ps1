﻿# ABRIR PORTAS do servidor (Dias de um Apocalipse). Chamado pelo abrir_portas.bat (que já pede administrador).
#   1) libera a porta UDP 24560 no FIREWALL do Windows (todas as redes: Wi-Fi, cabo, Tailscale)
#   2) pede ao ROTEADOR para abrir a porta 24560 (UPnP) apontando para este PC
#   3) confere se a sua internet tem CGNAT (aí porta nenhuma funciona de fora: use o Tailscale)
# "abrir_portas.bat fechar" desfaz tudo.
param([string]$acao = "abrir")

$PORTA = 24560
$NOME = "Dias de um Apocalipse - Servidor"
$ErrorActionPreference = "SilentlyContinue"

function Linha([string]$t, [string]$cor = "Gray") { Write-Host $t -ForegroundColor $cor }

function IpLocal {
    $c = Get-NetIPConfiguration | Where-Object { $_.IPv4DefaultGateway -ne $null -and $_.NetAdapter.Status -eq "Up" } | Select-Object -First 1
    if ($c) { return $c.IPv4Address.IPAddress }
    return $null
}

function IpPrivado([string]$ip) {
    if (-not $ip) { return $true }
    $p = $ip.Split(".") | ForEach-Object { [int]$_ }
    if ($p[0] -eq 10) { return $true }
    if ($p[0] -eq 192 -and $p[1] -eq 168) { return $true }
    if ($p[0] -eq 172 -and $p[1] -ge 16 -and $p[1] -le 31) { return $true }
    if ($p[0] -eq 100 -and $p[1] -ge 64 -and $p[1] -le 127) { return $true }   # faixa do CGNAT
    return $false
}

function Mapeamentos {
    $nat = New-Object -ComObject HNetCfg.NATUPnP
    if (-not $nat) { return $null }
    return $nat.StaticPortMappingCollection
}

Linha ""
Linha "=== Dias de um Apocalipse - portas do servidor (UDP $PORTA) ===" "Cyan"
Linha ""

if ($acao -eq "fechar") {
    Remove-NetFirewallRule -DisplayName $NOME
    Linha "[firewall] regra removida." "Yellow"
    $m = Mapeamentos
    if ($m) { $m.Remove($PORTA, "UDP"); Linha "[roteador] pedido para fechar a porta $PORTA enviado." "Yellow" }
    Linha ""
    Linha "Pronto: portas fechadas."
    exit
}

# ---- 1) firewall do Windows
Remove-NetFirewallRule -DisplayName $NOME
$r = New-NetFirewallRule -DisplayName $NOME -Direction Inbound -Protocol UDP -LocalPort $PORTA -Action Allow -Profile Any
if ($r) { Linha "[firewall] OK: porta UDP $PORTA liberada no Windows (todas as redes)." "Green" }
else { Linha "[firewall] NAO deu (rode o abrir_portas.bat de novo e aceite o pedido de administrador)." "Red" }

# ---- 2) roteador (UPnP)
$ip = IpLocal
if (-not $ip) {
    Linha "[roteador] NAO achei a rede deste PC (o PC esta conectado no Wi-Fi/cabo?)." "Red"
    exit
}
Linha "[rede] IP deste PC na sua casa: $ip"
$externo = $null
$m = Mapeamentos
if (-not $m) {
    Linha "[roteador] NAO respondeu ao UPnP." "Red"
    Linha "           Ligue a 'Descoberta de rede' do Windows (Configuracoes > Rede e Internet > Opcoes de compartilhamento)"
    Linha "           e o UPnP na pagina do roteador, ou abra a porta a mao (veja o LEIA-ME_SERVIDOR.txt)."
} else {
    $m.Remove($PORTA, "UDP")
    $novo = $m.Add($PORTA, "UDP", $PORTA, $ip, $true, $NOME)
    $item = $m.Item($PORTA, "UDP")
    if ($item) {
        $externo = $item.ExternalIPAddress
        Linha "[roteador] OK: porta $PORTA aberta para este PC ($ip)." "Green"
    } else {
        Linha "[roteador] o roteador recusou abrir a porta (UPnP desligado nele?)." "Red"
    }
}

# ---- 3) IP da internet e CGNAT
$publico = $null
try { $publico = (Invoke-RestMethod -Uri "https://api.ipify.org" -TimeoutSec 8).ToString().Trim() } catch {}
Linha ""
if ($publico) { Linha "[internet] seu IP na internet: $publico" }
if ($externo) { Linha "[internet] IP que o roteador recebe da operadora: $externo" }
Linha ""
if ($externo -and $publico -and ($externo -ne $publico -or (IpPrivado $externo))) {
    Linha "ATENCAO: sua operadora usa CGNAT (o roteador nao tem IP proprio na internet)." "Yellow"
    Linha "Abrir porta NAO adianta para quem esta fora de casa. Use o TAILSCALE (LEIA-ME_SERVIDOR.txt)." "Yellow"
    Linha "No mesmo Wi-Fi da sua casa continua funcionando normal ($ip)." "Yellow"
} elseif ($externo -and $publico) {
    Linha "TUDO CERTO! Amigos de fora entram no jogo com:   $publico" "Green"
    Linha "(no mesmo Wi-Fi da sua casa:   $ip)" "Green"
    Linha "Obs.: o IP da internet pode mudar quando o roteador reinicia: rode este arquivo de novo."
} else {
    Linha "Nao deu para abrir sozinho. Abra a porta a mao no roteador: porta $PORTA, protocolo UDP, para o IP $ip." "Yellow"
    Linha "Ou use o TAILSCALE (mais facil, funciona sempre)." "Yellow"
}
Linha ""
